/*
 * app.c
 *
 *  Created on: Jun 20, 2022
 *      Author: paulo
 */
#include <stdint.h>
#include "app.h"
#include "hw.h"

uint32_t time_led_delay = 100;

void app_switch_interrupt(void){
	// INTERRUPÇÃO A SER REALIZADA
	if(time_led_delay == 400){
		time_led_delay = 100;
	}else{
		time_led_delay = 400;
	}
}

void app_tick_1ms(void){
	// CRONÔMETRO DA REPETIÇÃO
	static uint32_t time_led_count = 0;

	time_led_count++;

	if(time_led_count >= time_led_delay){
		time_led_count = 0;
		hw_led_toggle();
	}
}

void app_init(void){

}

void app_loop(void){
	// MODO DE ECONOMIA DE ENERGIA
	hw_cpu_sleep();
}
