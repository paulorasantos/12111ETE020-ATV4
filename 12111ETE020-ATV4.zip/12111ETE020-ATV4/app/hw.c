/*
 * hw.c
 *
 *  Created on: Jun 20, 2022
 *      Author: paulo
 */

#include <stdint.h>
#include "main.h"
#include "app.h"

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin){
	// SE O BOTÃO FOR PRESSIONADO
	if(GPIO_Pin == USER_INPUT_Pin){
		app_switch_interrupt();
	}
}

void hw_led_toggle(void){
	HAL_GPIO_TogglePin(USER_LED_GPIO_Port,USER_LED_Pin);
}

void hw_cpu_sleep(void){
	__WFI();
}

