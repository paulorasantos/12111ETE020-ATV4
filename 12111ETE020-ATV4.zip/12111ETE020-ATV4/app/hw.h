/*
 * hw.h
 *
 *  Created on: Jun 20, 2022
 *      Author: paulo
 */

#ifndef HW_H_
#define HW_H_

void hw_led_toggle(void);
void hw_cpu_sleep(void);

#endif /* HW_H_ */
