#include <stdint.h>
#include <stdbool.h>
#include "app.h"
#include "hw.h"

#define APP_DEBOUCING_TIME_MS 50

volatile uint32_t led_time_ms = 100;

void app_switch_interrupt(void)
{
	static uint32_t deboucing_time_ms = 0;
	if((hw_tick_ms_get() - deboucing_time_ms) >= APP_DEBOUCING_TIME_MS)
	{
		if(led_time_ms == 400)
			led_time_ms = 100;
		else
			led_time_ms = 400;

		deboucing_time_ms = hw_tick_ms_get();
	}
}

void app_tick_1ms(void)
{
	static uint32_t led_time_cnt_ms = 0;

	led_time_cnt_ms++;

	if(led_time_cnt_ms >= led_time_ms)
	{
		led_time_cnt_ms = 0;
		hw_led_toggle();
	}
}

void app_init(void)
{

}
void app_loop(void)
{
	hw_cpu_sleep();

//	bool switch_state = hw_switch_state_get();
//	//GPIO_PinState switch_state = HAL_GPIO_ReadPin(INPUT_GPIO_Port, INPUT_Pin);
//
//	if(switch_state)
//		led_time_ms = 400;
//	else
//		led_time_ms = 100;

//	hw_led_state_set(true);
//	hw_delay_ms(led_time_ms);
//
//	hw_led_state_set(true);
//	hw_delay_ms(led_time_ms);

	/*HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_SET);
	HAL_Delay(led_time);

	HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET);
	HAL_Delay(led_time);*/
}
